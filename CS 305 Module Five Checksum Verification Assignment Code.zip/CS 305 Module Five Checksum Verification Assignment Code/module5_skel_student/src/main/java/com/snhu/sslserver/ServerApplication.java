package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class ServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }
}

@RestController
class ServerController {

    // Include your full name in the unique data string
    private static final String UNIQUE_DATA = "Tim Jayson | PublicKey v1";
    private static final String ALGORITHM   = "SHA-256";

    @RequestMapping("/hash")
    public String myHash() {
        byte[] digest = digest(ALGORITHM, UNIQUE_DATA.getBytes(StandardCharsets.UTF_8));
        String hex = toHex(digest); // 64 hex chars for SHA-256

        return new StringBuilder()
                .append("<html><body>")
                .append("<h2>Checksum Verification</h2>")
                .append("<p><b>uniqueData:</b> ").append(escape(UNIQUE_DATA)).append("</p>")
                .append("<p><b>algorithm:</b> ").append(ALGORITHM).append("</p>")
                .append("<p><b>checksumHex:</b> ").append(hex).append("</p>")
                .append("</body></html>")
                .toString();
    }

    private static byte[] digest(String algorithm, byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            return md.digest(data);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Unsupported algorithm: " + algorithm, e);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static String escape(String s) {
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
}