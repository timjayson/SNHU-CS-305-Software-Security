package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;

import java.security.MessageDigest;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    @RestController
    public static class HashController {

    	@GetMapping("/hash")
        public Map<String, String> getHash(@RequestParam(value = "data", defaultValue = "CS-305 | Tim Jayson | Artemis Financial") String data) {
            Map<String, String> response = new HashMap<>();
            try {
                // Hash the input string with SHA-256
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hashBytes = digest.digest(data.getBytes("UTF-8"));

                // Convert bytes to hex
                StringBuilder hexString = new StringBuilder();
                for (byte b : hashBytes) {
                    String hex = Integer.toHexString(0xff & b);
                    if (hex.length() == 1) hexString.append('0');
                    hexString.append(hex);
                }

                // Build structured JSON-style response
                response.put("CS-305", "Tim Jayson | Artemis Financial");
                response.put("timestamp", ZonedDateTime.now().toString());
                response.put("algorithm", "SHA-256");
                response.put("hash", hexString.toString());
                response.put("verification", "VERIFIED");

            } catch (Exception e) {
                response.put("error", "Hash generation failed: " + e.getMessage());
            }
            return response;
        }
    }
    public static class Checksum {

        public static String getSHA(String data) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hash = md.digest(data.getBytes("UTF-8"));
                StringBuilder hexString = new StringBuilder();
                for (byte b : hash) {
                    String hex = Integer.toHexString(0xff & b);
                    if (hex.length() == 1) hexString.append('0');
                    hexString.append(hex);
                }
                return hexString.toString();
            } catch (Exception e) {
                return "Error generating hash: " + e.getMessage();
            }
        }
    }
}